import { Route } from '../domain/types';
export interface RouteRepository {
  listAll(): Promise<Route[]>;
  setBaseline(routeId: string): Promise<void>;
}
