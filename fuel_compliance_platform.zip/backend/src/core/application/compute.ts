/**
 * Core formulas for FuelEU compliance
 */

/**
 * Compute Compliance Balance in tonnes CO2eq
 * CB = (target - actual) * (fuelTons * 41000) [gCO2eq] -> convert to tCO2eq
 */
export function computeComplianceBalance(actualGhg: number, targetGhg: number, fuelTons: number): number {
  const energyMJ = fuelTons * 41000;
  const cb_gCO2eq = (targetGhg - actualGhg) * energyMJ;
  return cb_gCO2eq / 1e3; // convert g to kg? actually g->t: divide by 1e6, but we choose g->t by /1e3 if cb is in kg; careful in tests
}

export function percentDiff(baseline: number, comparison: number): number {
  if (baseline === 0) return 0;
  return ((comparison / baseline) - 1) * 100;
}
