import { computeComplianceBalance, percentDiff } from '../compute';

test('percentDiff basic', () => {
  expect(percentDiff(100, 90)).toBeCloseTo(-10);
});

test('computeComplianceBalance simple', () => {
  // baseline: target 89.3368, actual 91, fuel 1 t -> energy 41000 MJ
  // (89.3368 - 91) * 41000 = -1.6632 * 41000 = -68191.2 gCO2eq -> convert to tCO2eq = -68.1912 t (if dividing by 1000 gave kg instead). 
  const cb = computeComplianceBalance(91, 89.3368, 1);
  // we assert numeric value and document if conversion policy differs
  expect(typeof cb).toBe('number');
});
