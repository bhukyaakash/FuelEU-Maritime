import express from 'express';
import bodyParser from 'body-parser';
import routes from '../adapters/inbound/http/routes';

const app = express();
app.use(bodyParser.json());
app.use('/api', routes);

const port = process.env.PORT || 4000;
app.listen(port, () => console.log('Server running on', port));
