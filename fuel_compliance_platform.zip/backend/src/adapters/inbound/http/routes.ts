import express from 'express';
import { InMemoryRouteRepo } from '../outbound/inMemoryRouteRepo';
import { computeComplianceBalance } from '../../core/application/compute';

const router = express.Router();
const repo = new InMemoryRouteRepo();

router.get('/routes', async (req, res) => {
  const all = await repo.listAll();
  res.json(all);
});

router.post('/routes/:routeId/baseline', async (req, res) => {
  const { routeId } = req.params;
  await repo.setBaseline(routeId);
  res.json({ success: true });
});

router.get('/routes/comparison', async (req, res) => {
  const all = await repo.listAll();
  const baseline = all.find(r => r.isBaseline) || all[0];
  const comparison = all.filter(r => !r.isBaseline);
  const rows = comparison.map(c => ({
    routeId: c.routeId,
    baselineGhg: baseline.ghgIntensity,
    comparisonGhg: c.ghgIntensity,
    percentDiff: ((c.ghgIntensity / baseline.ghgIntensity) - 1) * 100,
    compliant: c.ghgIntensity <= baseline.ghgIntensity * 0.98 // example: 2% below baseline target
  }));
  res.json({ baseline: baseline.routeId, rows });
});

export default router;
