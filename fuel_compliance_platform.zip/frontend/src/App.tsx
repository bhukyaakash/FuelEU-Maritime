import React, {useState} from 'react';
import RoutesTab from './tabs/RoutesTab';
import CompareTab from './tabs/CompareTab';

export default function App(){ 
  const [tab, setTab] = useState<'routes'|'compare'|'banking'|'pooling'>('routes');
  return (<div className='p-6 font-sans bg-slate-50 min-h-screen'>
    <h1 className='text-2xl font-bold mb-4'>FuelEU Compliance Dashboard</h1>
    <nav className='flex gap-3 mb-4'>
      <button onClick={()=>setTab('routes')} className='px-3 py-1 bg-white rounded shadow'>Routes</button>
      <button onClick={()=>setTab('compare')} className='px-3 py-1 bg-white rounded shadow'>Compare</button>
      <button onClick={()=>setTab('banking')} className='px-3 py-1 bg-white rounded shadow'>Banking</button>
      <button onClick={()=>setTab('pooling')} className='px-3 py-1 bg-white rounded shadow'>Pooling</button>
    </nav>
    <div className='bg-white rounded p-4 shadow'>{
      tab === 'routes' ? <RoutesTab /> : tab === 'compare' ? <CompareTab /> : <div>Other tabs (skeleton)</div>
    }</div>
  </div>)
}
