import React, {useEffect, useState} from 'react';
export default function CompareTab(){
  const [data, setData] = useState<any>(null);
  useEffect(()=>{ fetch('/api/routes/comparison').then(r=>r.json()).then(setData) }, []);
  if(!data) return <div>Loading...</div>;
  return (<div>
    <h2 className='text-xl font-semibold mb-2'>Compare</h2>
    <div>Baseline: {data.baseline}</div>
    <table>
      <thead><tr><th>routeId</th><th>baselineGhg</th><th>comparisonGhg</th><th>%diff</th><th>compliant</th></tr></thead>
      <tbody>{data.rows.map((r:any)=><tr key={r.routeId}><td>{r.routeId}</td><td>{r.baselineGhg}</td><td>{r.comparisonGhg}</td><td>{r.percentDiff.toFixed(2)}%</td><td>{r.compliant? '✅':'❌'}</td></tr>)}</tbody>
    </table>
  </div>)
}
