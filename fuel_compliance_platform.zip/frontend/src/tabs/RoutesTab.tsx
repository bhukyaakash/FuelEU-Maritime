import React, {useEffect, useState} from 'react';

type Route = { routeId:string; vesselType:string; fuelType:string; year:number; ghgIntensity:number; fuelConsumption:number; distanceKm:number; totalEmissions:number; isBaseline?:boolean };

export default function RoutesTab(){
  const [routes, setRoutes] = useState<Route[]>([]);
  useEffect(()=>{ fetch('/api/routes').then(r=>r.json()).then(setRoutes) }, []);
  return (<div>
    <h2 className='text-xl font-semibold mb-2'>Routes</h2>
    <table className='min-w-full text-left'>
      <thead><tr><th>routeId</th><th>vesselType</th><th>fuelType</th><th>year</th><th>ghgIntensity</th><th>fuelConsumption</th><th>distance (km)</th><th>totalEmissions</th><th>baseline</th><th>actions</th></tr></thead>
      <tbody>{routes.map(r=> <tr key={r.routeId}><td>{r.routeId}</td><td>{r.vesselType}</td><td>{r.fuelType}</td><td>{r.year}</td><td>{r.ghgIntensity}</td><td>{r.fuelConsumption}</td><td>{r.distanceKm}</td><td>{r.totalEmissions}</td><td>{r.isBaseline? '✅':''}</td><td><button onClick={()=>fetch('/api/routes/'+r.routeId+'/baseline',{method:'POST'}).then(()=>window.location.reload())} className='px-2 py-1 bg-blue-500 text-white rounded'>Set Baseline</button></td></tr>)}</tbody>
    </table>
  </div>);
}
