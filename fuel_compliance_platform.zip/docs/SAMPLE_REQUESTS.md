# Sample requests (using curl)

GET all routes:
```
curl http://localhost:4000/api/routes
```

Set baseline:
```
curl -X POST http://localhost:4000/api/routes/R001/baseline
```

Get comparison:
```
curl http://localhost:4000/api/routes/comparison
```
